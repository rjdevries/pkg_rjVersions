--
-- Remove table `#__versions`
--
DROP TABLE `#__versions`;